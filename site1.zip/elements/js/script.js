let open_element=document.querySelectorAll(".knop_js");
let element=document.querySelectorAll(".elements");

open_element[0].onclick = function(){
  element[0].classList.toggle("_active");

}
open_element[1].onclick = function(){
  element[1].classList.toggle("_active");
}
open_element[2].onclick = function(){
  element[2].classList.toggle("_active");
}
open_element[3].onclick = function(){
  element[3].classList.toggle("_active");
}
open_element[4].onclick = function(){
  element[4].classList.toggle("_active");
}
open_element[5].onclick = function(){
  element[5].classList.toggle("_active");
}
open_element[6].onclick = function(){
  element[6].classList.toggle("_active");
}
open_element[7].onclick = function(){
  element[7].classList.toggle("_active");
}
open_element[8].onclick = function(){
  element[8].classList.toggle("_active");
}
open_element[9].onclick = function(){
  element[9].classList.toggle("_active");
}
open_element[10].onclick = function(){
  element[10].classList.toggle("_active");
}

open_element[11].onclick = function(){
  element[11].classList.toggle("_active");
}

open_element[12].onclick = function(){
  element[12].classList.toggle("_active");
}

open_element[13].onclick = function(){
  element[13].classList.toggle("_active");
}

open_element[14].onclick = function(){
  element[14].classList.toggle("_active");
}

open_element[15].onclick = function(){
  element[15].classList.toggle("_active");
}

open_element[16].onclick = function(){
  element[16].classList.toggle("_active");
}

open_element[17].onclick = function(){
  element[17].classList.toggle("_active");
}

open_element[18].onclick = function(){
  element[18].classList.toggle("_active");
}

open_element[19].onclick = function(){
  element[19].classList.toggle("_active");
}

open_element[20].onclick = function(){
  element[20].classList.toggle("_active");
}

open_element[21].onclick = function(){
  element[21].classList.toggle("_active");
}
